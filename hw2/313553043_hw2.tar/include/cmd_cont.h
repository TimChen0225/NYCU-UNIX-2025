#pragma once
#include <string>

/* 連續執行直到程式結束或命中 breakpoint / signal */
void cmd_cont(const std::string &args);
