#pragma once
#include <string>

/* syscall —— 持續執行；在每次系統呼叫 entry / exit 停下 */
void cmd_syscall(const std::string &args);
