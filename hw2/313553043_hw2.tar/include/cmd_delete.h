#pragma once
#include <string>

/* 刪除 breakpoint ，對應指令： delete <id> */
void cmd_delete(const std::string &args);
