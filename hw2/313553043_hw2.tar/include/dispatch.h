#pragma once
#include <string>

/* 把指令 & 參數交給全域表分派 */
void dispatch(const std::string &cmd, const std::string &args);
