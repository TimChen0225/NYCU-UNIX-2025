#pragma once
#include <string>

/* patch <addr> <hex-string> */
void cmd_patch(const std::string &args);
